package com.infocare.first.server.client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.infocare.first.server.config.ClientConfiguration;
import com.infocare.first.server.model.MultiplyRequest;

@FeignClient(name = "SecondServerService", url = "http://localhost:8081",configuration = ClientConfiguration.class)
public interface SecondServerClient {

	 @PostMapping("/multiply")
	 public int multiply(@RequestBody MultiplyRequest multiplyRequest);
}
