package com.infocare.first.server.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * ClientConfiguration is used configure the client properties.
 * @author  Roshni Gupta
 */
@Configuration
@ConfigurationProperties(prefix = "second.server")
public class ClientConfiguration {

	private String url;

	private int connectionTimeOut;

	private int readTimOut;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getConnectionTimeOut() {
		return connectionTimeOut;
	}

	public void setConnectionTimeOut(int connectionTimeOut) {
		this.connectionTimeOut = connectionTimeOut;
	}

	public int getReadTimOut() {
		return readTimOut;
	}

	public void setReadTimOut(int readTimOut) {
		this.readTimOut = readTimOut;
	}

	@Override
	public String toString() {
		return "ReadConfiguration [url=" + url + ", connectionTimeOut=" + connectionTimeOut + ", readTimOut="
				+ readTimOut + "]";
	}

}
