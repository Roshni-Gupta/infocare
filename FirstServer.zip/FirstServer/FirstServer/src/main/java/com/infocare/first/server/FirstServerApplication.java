package com.infocare.first.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignAutoConfiguration;

/**
 * FirstServerApplication is a bootstrap point
 * @author  Roshni Gupta
 */
@SpringBootApplication
@EnableFeignClients
@ImportAutoConfiguration({FeignAutoConfiguration.class})
public class FirstServerApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(FirstServerApplication.class, args);
	}

}
