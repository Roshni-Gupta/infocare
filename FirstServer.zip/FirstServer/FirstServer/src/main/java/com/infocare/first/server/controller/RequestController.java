package com.infocare.first.server.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infocare.first.server.client.SecondServerClient;
import com.infocare.first.server.model.MultiplyRequest;

/**
 * RequestController is used to send request to another server.
 * @author  Roshni Gupta
 */
@RestController
public class RequestController {
	private static Logger logger = LoggerFactory.getLogger(RequestController.class);
	
	@Autowired
	SecondServerClient secondServerClient;

	@PostMapping("/multiply")
	public int multiply(@RequestBody MultiplyRequest multiplyRequest) {
		logger.debug("Request Received :{} ",multiplyRequest.toString());
		return secondServerClient.multiply(multiplyRequest);
	}
}
