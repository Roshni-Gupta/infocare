package com.infocare.first.server.error;

/**
 * BadRequestException is custom Exception
 * @author  Roshni Gupta
 */
public class BadRequestException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public BadRequestException(String msg) {
		super(msg);
	}
}
