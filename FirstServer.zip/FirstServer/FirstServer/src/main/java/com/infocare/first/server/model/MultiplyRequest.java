package com.infocare.first.server.model;

/**
 * MultiplyRequest is a bean
 * 
 * @author Roshni Gupta
 */
public class MultiplyRequest {

	private int num1;
	private int num2;

	/**
	 * @return num1 (in int)
	 */
	public int getNum1() {
		return num1;
	}

	/**
	 * 
	 * @param num1 num1 to set (in int)
	 */
	public void setNum1(int num1) {
		this.num1 = num1;
	}

	/**
	 * @return num2 (in int)
	 */
	public int getNum2() {
		return num2;
	}

	/**
	 * 
	 * @param num2 num2 to set (in int)
	 */
	public void setNum2(int num2) {
		this.num2 = num2;
	}

}
