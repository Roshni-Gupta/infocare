package com.infocare.SecondServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecondServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
