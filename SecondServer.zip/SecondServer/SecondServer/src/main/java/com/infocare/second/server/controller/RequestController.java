package com.infocare.second.server.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infocare.second.server.model.MultiplyRequest;

@RestController
public class RequestController {

	private static Logger logger = LoggerFactory.getLogger(RequestController.class);

	@PostMapping("/multiply")
	public int multiply(@RequestBody MultiplyRequest multiplyRequest) {
		logger.debug("Request Received : {}",multiplyRequest.toString() );
		return multiplyRequest.getNum1() * multiplyRequest.getNum2();
	}
}
