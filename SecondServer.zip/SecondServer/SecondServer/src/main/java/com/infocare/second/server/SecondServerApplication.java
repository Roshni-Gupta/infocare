package com.infocare.second.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecondServerApplication.class, args);
	}

}
